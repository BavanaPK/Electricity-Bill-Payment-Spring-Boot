package com.ebp.in.entity;

public enum PaymentMode {
	CREDIT, DEBIT, WALLET, NETBANKING;

}
