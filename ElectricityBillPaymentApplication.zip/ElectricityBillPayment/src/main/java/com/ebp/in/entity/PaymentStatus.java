package com.ebp.in.entity;

public enum PaymentStatus {
	
	SUCCESS, FAILED;

}
