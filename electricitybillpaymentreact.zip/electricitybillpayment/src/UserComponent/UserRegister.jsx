import React from "react"
import  UserService  from "../services/UserService"

export default class UserRegister extends React.Component{

    constructor(props){
        super(props)

        this.state={
            username:'',
            password:'',
            mobile:'',
            email:'',
            msg:'',
            error:{}

        }
    }

    handleUserName=(event)=>
    {
        this.setState({
            username:event.target.value

        })
    }

    handlePassword=(event)=>
    {
        this.setState({
            password:event.target.value

        })
    }

    handleMobile=(event)=>
    {
        this.setState({
            mobile:event.target.value

        })
    }

    handleEmail=(event)=>
    {
        this.setState({
            email:event.target.value

        })
    }

    formValidation=()=>{
        const {username,password,mobile,errors}=this.state;
        let isValid=true;
        if(username.trim().length<6){
            errors.usernameLength="Username must be of Length 6 or higher";
            isValid=false;
        }
        if(!username.includes("$")){
            errors.username$="Username must have $ sign";
            isValid=false;
        }
        if(password.trim().length<8){
            errors.passwordLength="Password must be of length 8 or higher";
            isValid=false;
        }
        this.setState({errors});
        return isValid;
    }

    handleForSubmission=(event)=>
    {
        event.preventDefault()
        const isValid=this.formValidation();
        if(isValid){
            this.setState({username:"",password:""});
        }
        this.saveUser(this.state)
    }

    saveUser(user)
    {
        UserService.addUser(user).then(response=>
            {  
                console.log(response)
                this.setState({
                    username:'',
                    password:'',
                    mobile:'',
                    email:'',
                    msg:response.data,
                    error:''        
                    
                })
            })
            .catch(error=>console.log(error))

    }

    render()
    {
        return(
            <div className="container">
            <h2 className="text-info">Registration</h2>
            <hr />
            <form onSubmit={this.handleForSubmission}>
                <div className="form-group">
                    <label>User Name</label>
                    <input onChange={this.handleUserName} value={this.state.username} className="form-control" />
                </div>
                <div className="form-group">
                    <label>Password</label>
                    <input onChange={this.handlePassword} value={this.state.password} className="form-control" type="password" />
                </div>
                <div className="form-group">
                    <label>Mobile</label>
                    <input onChange={this.handleMobile} value={this.state.mobile} className="form-control" />
                </div>
                <div className="form-group">
                    <label>Email</label>
                    <input onChange={this.handleEmail} value={this.state.email} className="form-control" />
                </div>
                <button className="btn btn-primary mt-2">Submit</button>
            </form>
                    {
                        this.state.msg && <h5 className="alert alert-success mt-2">{this.state.msg}</h5>
                    }
            </div>
        )
    }

} 