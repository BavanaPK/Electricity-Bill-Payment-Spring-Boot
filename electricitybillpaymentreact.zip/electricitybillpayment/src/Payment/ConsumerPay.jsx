import axios from "axios";
import React, {useEffect,useState} from "react";
export default function ConsumerPay() {

    const [consumerNumber,setConsumerNumber] = useState('')
    const [consumerNumberFromBtn,setConsumerNumberFromBtn] = useState('')
    const [payment,setPayment]= useState({})
    const [error,setError]=useState(false)

    useEffect(()=>
    {
        axios.get(`http://localhost:8080/payment/consumerNumber/${consumerNumber}`)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)
                setPayment(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log("error.msg")
                    setError(true)
                })
    },[consumerNumberFromBtn]
    
    )

    return(
        <div className="container">
       <h3>Search For Payment</h3>
       <hr/>
       <div className="form-group">
        <label>Consumer Number</label>
        <input value={consumerNumber} onChange={(event)=>setConsumerNumber(event.target.value)} className="form-control"/>
       </div>
       <button onClick={()=>setConsumerNumberFromBtn(consumerNumber)} className="btn btn-primary mt-3">Search</button>
       <hr/>
       {
           error?
           <h5 className="text-danger">Payment Is Not Available</h5>
           
        : 
        <div>
        <h3>Consumer Number : {consumerNumber}</h3>
        <ul className="list-group">
            <li>Payment Id : {payment.paymentId} </li>
            <li>Bill billpayment : {payment.billpayment} </li>
            <li>PaymentDate : {payment.paymentdate}</li>
            <li>PaymentMode : {payment.paymentmode}</li>
            <li>latePaymentCharges : {payment.latepaymentCharges}</li>
            <li>totalpaid : {payment.totalpaid}</li>
            <li>PaymentStatus status : {payment.paymentstatus}</li>
        </ul>
       </div>
       }
   </div>
)

}