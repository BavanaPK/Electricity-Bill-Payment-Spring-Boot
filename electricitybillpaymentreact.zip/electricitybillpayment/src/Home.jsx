import React from 'react'
import img1 from './Images/Elecanime.jpg'

function Home() {
    return (
        <div className="container">
            <img src={img1} className="main-container" alt="Blog" />
            
        </div>
    )
}

export default Home
