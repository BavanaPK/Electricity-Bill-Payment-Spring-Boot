import React from "react";

class Footer extends React.Component
{
    render()
    {
        return(

            <div class="footer">
            <p style={{textAlign:"center"}}>For any quires related to online applications,please mail customercare@userservice or contact customer center 1839-289-7897,1800-378-6786</p>
            </div>
        )
    }
}
export default Footer;