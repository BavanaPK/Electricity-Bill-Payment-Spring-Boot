import React from "react";
import { BrowserRouter as Router,Route,Switch} from 'react-router-dom';
import "./App.css";
import Home from './Home';
import { Main } from './Main';

import img1 from './Images/Elecanime.jpg';

import { BillConsumerNumber } from './Bill/BillConsumerNumber';
import { BillEmail } from './Bill/BillEmail';
import { BillMobile } from './Bill/BillMobile';

import Submit from './Reading/Submit';
import GetBillDate from './Reading/GetBillDate';
import { GetConsumerNumber } from './Reading/GetConsumerNumber';

import Footer from './Footer';
import RegisterCustomer from "./Customer/RegisterCustomer";
import ViewAllCustomer from "./Customer/ViewAllCustomer";
import ViewCustomerById from "./Customer/ViewCustomerById";
import ViewCustomerByEmail from "./Customer/ViewCustomerByEmail";
import ViewCustomerByAadhaar from "./Customer/ViewCustomerByAadhaar";
import ViewCustomerByMobileNumber from "./Customer/ViewCustomerByMobileNumber";
import ViewCustomerByName from "./Customer/ViewCustomerByName";
import UserRegister from "./UserComponent/UserRegister";
import Login from "./UserComponent/Login";

import NewConnectionRequest  from './Connection/NewConnectionRequest';
import ViewCustomerByConsumerNumber from './Connection/ViewCustomerByConsumerNumber'
import ViewActiveConnectionsByVillage from './Connection/ViewActiveConnectionsByVillage';
import ViewActiveConnectionsByTaluk from './Connection/ViewActiveConnectionsByTaluk';
import ViewActiveConnectionsByDistrict from './Connection/ViewActiveConnectionsByDistrict';
import ViewActiveConnectionsByPincode from './Connection/ViewActiveConnectionsByPincode';
import ConsumerPay from "./Payment/ConsumerPay";


function App() {

  return (
    <div>
    <Router>
   {/* <Login/>*/} 
    <Main/>
    <Route exact path="/" component={Home}/>

     <Route exact path="/user-register" component={UserRegister} />
     <Route exact path="/login" component={Login}/>

     <Route exact path="/register-customer" component={RegisterCustomer}/>
      <Route exact path="/view-all-customer" component={ViewAllCustomer}/>
      <Route exact path="/view-customer-by-id" component={ViewCustomerById}/>
      <Route exact path="/view-customer-by-email" component={ViewCustomerByEmail}/>
      <Route exact path="/view-customer-by-aadhaar" component={ViewCustomerByAadhaar}/>
      <Route exact path="/view-customer-by-mobile" component={ViewCustomerByMobileNumber}/>
      <Route exact path="/view-customer-by-name" component={ViewCustomerByName}/>
      <Route exact path="/edit-customer/:customerId" component={RegisterCustomer}/>



      <Route exact path="/new-connection-request" component={NewConnectionRequest}/>
      <Route exact path="/view-customer-by-consumer-number" component={ViewCustomerByConsumerNumber}/>
      <Route exact path="/view-active-connections-by-village" component={ViewActiveConnectionsByVillage}/>
      <Route exact path="/view-active-connections-by-taluk" component={ViewActiveConnectionsByTaluk}/>
      <Route exact path="/view-active-connections-by-district" component={ViewActiveConnectionsByDistrict}/>
      <Route exact path="/view-active-connections-by-pincode" component={ViewActiveConnectionsByPincode}/>


    
     <Route exact path="/getbilldate" component={GetBillDate}/>
     <Route exact path="/getconsumernumber" component={GetConsumerNumber}/>

     <Route exact path="/billemail" component={BillEmail}/>
     <Route exact path="/billmobile" component={BillMobile}/>
     <Route exact path="/billconsumernumber" component={BillConsumerNumber}/>

     <Route exact path="/consumerpay" component={ConsumerPay}/>
  </Router>

    <Footer></Footer>
    
    </div>
  )
};

export default App;
