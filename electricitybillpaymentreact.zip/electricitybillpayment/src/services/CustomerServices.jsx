import axios from "axios";

const COUSTOMER_LIST_URL = 'http://localhost:8080/customer/viewCustomersProfile'
const CUSTOMER_REGISTER_URL = 'http://localhost:8080/customer/register'
const CUSTOMER_EDIT_URL = 'http://localhost:8080/customer/edit'
const CUSTOMER_BASE_URL = 'http://localhost:8080/customer'
class CustomerService{

    getAllCustomers(){
        return axios.get(COUSTOMER_LIST_URL)
    }

    registerCustomer(customer){
        return axios.post(CUSTOMER_REGISTER_URL,customer)
    }

    getCustomerById(customerId){
        return axios.get(CUSTOMER_BASE_URL+'/'+customerId)
    }

    editCustomer(customerId,customer){
        return axios.put(CUSTOMER_EDIT_URL+'/'+customerId,customer)
    }

    getCustomerByMobile(mobileNumber){
        return axios.get(CUSTOMER_BASE_URL+'/mobile/'+mobileNumber)
    }

    getCustomerByEmail(email){
        return axios.get(CUSTOMER_BASE_URL+'/email/'+email)
    }

    getCustomerByName(firstName){
        return axios.get(CUSTOMER_BASE_URL+'/name/'+firstName)
    }

    getCustomerByAadhaar(aadhaarNumber){
        return axios.get(CUSTOMER_BASE_URL+'/aadhaar/'+aadhaarNumber)
    }
}


export default new CustomerService();