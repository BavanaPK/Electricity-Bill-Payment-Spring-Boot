const Validation = (values) => {

    let errors={};

    if(!values.username){
        errors.username="Username is required"
    }

    if(!values.email){
        errors.email="Email is required"
    } 

    if(!values.password){
        errors.password="Password is required"
    } else if(values.password.length<5){
        errors.password="Password type is invalid"
    }


    return errors
}

export default Validation;
