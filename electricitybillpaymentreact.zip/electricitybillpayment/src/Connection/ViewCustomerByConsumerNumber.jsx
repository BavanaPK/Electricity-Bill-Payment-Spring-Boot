import React,{useEffect,useState} from "react";
import axios from "axios";
function ViewCustomerByConsumerNumber() {

    const [consumerNumber,setConsumerNumber]=useState('')
    const [customer,setCustomer]=useState({})
    const [consumerNumberFromBtn,setConsumerNumberFromBtn]=useState('')
    const [error,setError]=useState(false)

    useEffect(()=>
    {
        axios.get(`http://localhost:8081/connection/consumernumber/${consumerNumber}`)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)
                setCustomer(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log("error.msg")
                    setError(true)
                })
    },[consumerNumberFromBtn]
    
    )


    return (
        <div className="container">
            <h2 className="text-primary">View Customer By Consumer Number</h2>
            <hr/>
            <div className="form-group">
                <label>Consumer Number</label>
                <span className="required">*</span>
                <input value={consumerNumber} onChange={(event)=>setConsumerNumber(event.target.value)} className="form-control"/>
            </div>
            <button onClick={()=>setConsumerNumberFromBtn(consumerNumber)} className="btn btn-primary mt-3">Serach</button>
            <hr/>
            {
                error?

                <h5 className="text-danger">Customer Not Available</h5>

                :
             <div>
                <h3>Consumer Number:{consumerNumber} Details</h3>
                <ul className="list-group">
                    <li className="list-group-item list-group-item-success">Customer ID: {customer.customerId}</li>
                    <li className="list-group-item list-group-item-success">First Name:{customer.firstName}</li>
                    <li className="list-group-item list-group-item-success">Last name:{customer.lastName}</li>
                </ul>
        </div>
        }
        </div>
                    
    ) 
}

export default ViewCustomerByConsumerNumber