import React, { Component } from "react";
import axios from "axios";

export default class NewConnectionRequest extends Component{
constructor(props){
    super(props)
    
    this.state={
         connectionId : '',
         applicationDate : '',
         connectionDate : '',
         connectionStatus : '',
         connectionType : '',
         consumerNumber : '',
         addressId : '',
         userId : ''

    }
}

connectionIdHandler=(e)=>{
    this.setState({
        connectionId:e.target.value,
    })
}

applicationDateHandler=(e)=>{
    this.setState({
        applicationDate:e.target.value
})
}
connectionDateHandler=(e)=>{
    this.setState({
        connectionDate:e.target.value
})
}

connectionStatusHandler=(e)=>{
    this.setState({
        connectionStatus:e.target.value
})
}

connectionTypeHandler=(e)=>{
    this.setState({
        connectionType:e.target.value
})
}

consumerNumberHandler=(e)=>{
    this.setState({
        consumerNumber:e.target.value
})
}

addressIdHandler=(e)=>{
    this.setState({
        addressId:e.target.value
})
}

userIdHandler=(e)=>{
    this.setState({
        userId:e.target.value
})
}

submitHandler=(e)=>{
    e.preventDefault()
    console.log(this.state)
    axios.post('http://localhost:8081/newConnection',this.state)
    .then(response => {
        console.log(response)
    })
    .catch(error=>{
        console.log(error)
    })
}

    render(){
        const { connectionId, applicationDate, connectionDate, connectionStatus, connectionType, consumerNumber, addressId, userId} = this.state
        return(
            <div>
                <form onSubmit={this.submitHandler} class="align-items-center">
                    <div class="row justify-content-center align-items-center h-100">
                        <div class="col col-sm-6 col-md-6 col-lg-4 col-xl-3">
                    
                            <div class="form-group">
                                <div class="row">
                                    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg" >Connection_Id</label>
                                    <input type="text" class="form-control" id="inputConnectionId" value = {connectionId}  onChange={this.connectionIdHandler}/>
                                    
                                    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg" >Application_Date</label>
                                    <input type="text" class="form-control" id="inputApplicationDate"  value={applicationDate} onChange={this.applicationDateHandler}/>
                                
                                    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg"  >Connection_Date</label>
                                    <input type="text" class="form-control" id="inputConnectionDate" value={connectionDate} onChange={this.connectionDateHandler}/>
                            
                                    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg" >Connection_Status</label>
                                    <input type="text" class="form-control" id="inputConnectionStatus" value={connectionStatus}  onChange={this.connectionStatusHandler}/>
                            
                                    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg" >Connection_Type</label>
                                    <input type="text" class="form-control" id="inputConnectionType"  value = {connectionType}  onChange={this.connectionTypeHandler}/>
                                
                                    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg" >Consumer_Number</label>
                                    <input type="text" class="form-control" id="inputconsumerNumber"  value = {consumerNumber} onChange={this.consumerNumberHandler}/>

                                    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg" >Address_Id</label>
                                    <input type="text" class="form-control" id="inputaddressId"  value = {addressId} onChange={this.addressIdHandler}/>

                                    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg" >User_Id</label>
                                    <input type="text" class="form-control" id="inputUserId"  value = {userId} onChange={this.userIdHandler}/>
                                </div>    
                                
                                <br/>
                                <div class="d-grid gap-2 col-6 mx-auto">
                                    <button type="submit" class="btn btn-primary" >Create</button>
                                </div>
                            </div> 
                        </div>
                    </div>      
                </form>
            </div>
        )
    }
}