import React, {useEffect,useState} from "react";
import axios from "axios";
function ViewActiveConnectionsByPincode() {

    const [pincode,setPincode] = useState('')
    const [pincodeFromBtn,setPincodeFromBtn] = useState('')
    const [connection,setConnection]= useState({})
    const [error,setError]=useState(false)

    useEffect(()=>
    {
        axios.get(`http://localhost:8081/pincode/${pincode}`)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)
                setConnection(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log("error.msg")
                    setError(true)
                })
    },[pincodeFromBtn]
    
    )

   return (
       <div className="container">
           <h3>View Active Connections By Pincode</h3>
           <hr/>
           <div className="form-group">
            <label>Pincode</label>
            <span className="required">*</span>
            <input value={pincode} onChange={(event)=>setPincode(event.target.value)} className="form-control"/>
           </div>
           <button onClick={()=>setPincodeFromBtn(pincode)} className="btn btn-primary mt-3">Search</button>
           <hr/>
           {
               error?

               <h5 className="text-danger">Connections not available</h5>
            : 
            <div>
           <h3>Taluk : {pincode}</h3>
           <ul className="list-group">
                    <li>Connection Id:{connection.connectionId}</li>
                    <li>Consumer Number:{connection.consumerNumber}</li>
                    <li>Customer Connection:{connection.customerConnection}</li>
                    <li>Connection Address:{connection.connectionAddress}</li>
                    <li>Connection Type:{connection.connectionType}</li>
                    <li>Application Date:{connection.applicationDate}</li>
                    <li>Connection Date:{connection.connectionDate}</li>
                    <li>Village:{connection.village}</li>
                    <li>Taluk:{connection.taluk}</li>
                    <li>District:{connection.district}</li>
                    <li>Pincode:{connection.pincode}</li>
           </ul>
           </div>
           
           }
       </div>
   )
}

export default ViewActiveConnectionsByPincode