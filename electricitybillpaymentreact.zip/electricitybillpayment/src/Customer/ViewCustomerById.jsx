import React,{useState, useEffect} from "react";
import CustomerServices from "../services/CustomerServices";
export default function ViewCustomerById(){
    
    const[customerId,setCustomerId]=useState(1)
    const[customer,setCustomer]=useState({})
    const[idFromButton,setIdFromButton]=useState(0)
    const[error,setError]=useState(false)

    useEffect(()=>
    {
        CustomerServices.getCustomerById(customerId)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)

                setCustomer(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log(error.message)
                    setError(true)
                })
    },[idFromButton]
    )

    return(
       <div className="container">
        <h2 className="text-info">View Customer By Id</h2>
        <hr />
        <div className="form-group">
            <label>Customer ID</label>
            <input value={customerId} onChange={(event)=>setCustomerId(event.target.value)} className="form-control"/>
        </div>
        <button onClick={()=>setIdFromButton(customerId)} className="m-2 btn btn-primary">Search</button>
        <hr/>
        {
            !error?
            <div>
                <h3>Customer ID:{customerId}</h3>
                <ul>
                     <li>Customer ID :{customer.customerId}</li>
                     <li>Customer First Name :{customer.firstName}</li>
                     <li>Customer Middle Name :{customer.middleName}</li>
                     <li>Customer Last Name :{customer.lastName}</li>
                     <li>Customer Phone Number :{customer.mobileNumber}</li>
                     <li>Customer Addhaar :{customer.addharNumber}</li>
                     <li>Customer Gender :{customer.gender}</li>
                </ul>
                </div>:
                <h5>No Customer Found</h5>

        }
    </div>)

}
