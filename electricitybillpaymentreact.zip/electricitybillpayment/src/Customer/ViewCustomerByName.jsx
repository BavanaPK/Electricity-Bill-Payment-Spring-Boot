import React,{useState, useEffect} from "react";
import CustomerServices from "../services/CustomerServices";
export default function ViewCustomerByEmai(){

    const[firstName,setFirstName]=useState('')
    const[customer,setCustomer]=useState({})
    const[nameFromButton,setNameFromButton]=useState('')
    const[error,setError]=useState(false)

    useEffect(()=>
    {
        CustomerServices.getCustomerByName(firstName)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)

                setCustomer(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log(error.message)
                    setError(true)
                })
    },[nameFromButton]
    )
    
        return(
            <div className="container">
            <h2 className="text-info">View Customer By Name</h2>
            <hr />
            <div className="form-group">
                <label>Search By Name</label>
                <input value={firstName} onChange={(event)=>setFirstName(event.target.value)} className="form-control"/>
            </div>
            <button onClick={()=>setNameFromButton(firstName)} className="m-2 btn btn-primary">Search</button>
            <hr/>
            {
                !error?
                <div>
                    <h3>Customer Name:{firstName}</h3>
                    <ul>
                       
                        <li>Customer ID :{customer.customerId}</li>
                        <li>Customer First Name :{customer.firstName}</li>
                        <li>Customer Middle Name :{customer.middleName}</li>
                        <li>Customer Last Name :{customer.lastName}</li>
                        <li>Customer Phone Number :{customer.mobileNumber}</li>
                        <li>Customer Addhaar :{customer.aadhar}</li>
                        <li>Customer Email :{customer.email}</li>
                        <li>Customer Gender :{customer.gender}</li>
                        
                    </ul>
                    </div>:
                    <h5>No Customer Found</h5>

            }
        </div>
        )
    
}