import React,{useState, useEffect} from "react";
import CustomerServices from "../services/CustomerServices";
export default function ViewCustomerByEmail(){

    const[email,setEmail]=useState('')
    const[customer,setCustomer]=useState({})
    const[emailFromButton,setEmailFromButton]=useState('')
    const[error,setError]=useState(false)

    useEffect(()=>
    {
        CustomerServices.getCustomerByEmail(email)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)

                setCustomer(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log(error.message)
                    setError(true)
                })
    },[emailFromButton]
    )
    
        return(
            <div className="container">
            <h2 className="text-info">View Customer By Email</h2>
            <hr />
            <div className="form-group">
                <label>Search By Email</label>
                <input value={email} onChange={(event)=>setEmail(event.target.value)} className="form-control"/>
            </div>
            <button onClick={()=>setEmailFromButton(email)} className="m-2 btn btn-primary">Search</button>
            <hr/>
            {
                !error?
                <div>
                    <h3>Customer Eamil:{email}</h3>
                    <ul>
                        <li>Customer ID :{customer.customerId}</li>
                        <li>Customer First Name :{customer.firstName}</li>
                        <li>Customer Middle Name :{customer.middleName}</li>
                        <li>Customer Last Name :{customer.lastName}</li>
                        <li>Customer Phone Number :{customer.mobileNumber}</li>
                        <li>Customer Addhaar :{customer.addharNumber}</li>
                        <li>Customer Email :{customer.email}</li>
                        <li>Customer Gender :{customer.gender}</li>
                    </ul>
                    </div>:
                    <h5>No Customer Found</h5>

            }
        </div>
        )
    
}