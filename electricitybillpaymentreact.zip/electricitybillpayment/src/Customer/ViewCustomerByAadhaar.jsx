import React,{useState, useEffect} from "react";
import CustomerServices from "../services/CustomerServices";
export default function ViewCustomerByAadhaar(){

    const[aadhaarNumber,setAadhaarnumber]=useState(0)
    const[customer,setCustomer]=useState({})
    const[aadhaarFromButton,setAadhaarFromButton]=useState('')
    const[error,setError]=useState(false)

    useEffect(()=>
    {
        CustomerServices.getCustomerByAadhaar(aadhaarNumber)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)

                setCustomer(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log(error.message)
                    setError(true)
                })
    },[aadhaarFromButton]
    )
    
        return(
            <div className="container">
            <h2 className="text-info">View Customer By Aadhaar</h2>
            <hr />
            <div className="form-group">
                <label>Search By Aadhaar Number</label>
                <input value={aadhaarNumber} onChange={(event)=>setAadhaarnumber(event.target.value)} className="form-control"/>
            </div>
            <button onClick={()=>setAadhaarFromButton(aadhaarNumber)} className="m-2 btn btn-primary">Search</button>
            <hr/>
            {
                !error?
                <div>
                    <h3>Customer Aadhaar:{aadhaarNumber}</h3>
                    <ul>
                        <li>Customer ID :{customer.customerId}</li>
                        <li>Customer First Name :{customer.firstName}</li>
                        <li>Customer Middle Name :{customer.middleName}</li>
                        <li>Customer Last Name :{customer.lastName}</li>
                        <li>Customer Phone Number :{customer.mobileNumber}</li>
                        <li>Customer Aadhaar :{customer.aadhaarNumber}</li>
                        <li>Customer Email :{customer.email}</li>
                        <li>Customer Gender :{customer.gender}</li>
                    </ul>
                    </div>:
                    <h5>No Customer Found</h5>

            }
        </div>
        )
    
}