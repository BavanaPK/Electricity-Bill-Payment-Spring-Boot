import React,{useState, useEffect} from "react";
import CustomerServices from "../services/CustomerServices";
export default function ViewCustomerByMobileNumber(){

    const[mobileNumber,setMobileNumber]=useState('')
    const[customer,setCustomer]=useState({})
    const[mobileFromButton,setMobileFromButton]=useState('')
    const[error,setError]=useState(false)
   

    useEffect(()=>
    {
        CustomerServices.getCustomerByMobile(mobileNumber)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)

                setCustomer(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log(error.message)
                    setError(true)
                })
    },[mobileFromButton]
    )

    
    
        return(
            <div className="container">
            <h2 className="text-info">View Customer By Mobile Number</h2>
            <hr />
            
            <div className="form-group">
                <label>Search By Mobile Number</label>

               
                <input value={mobileNumber} onChange={(event)=>setMobileNumber(event.target.value)} className="form-control"/>
            </div>
            <button onClick={()=>setMobileFromButton(mobileNumber)} className="m-2 btn btn-primary">Search</button>
            <hr/>
            {
                !error?
                <div>
                    <h3>Customer Mobile Number:{mobileNumber}</h3>
                    <ul>
                        <li>Customer ID :{customer.customerId}</li>
                        <li>Customer First Name :{customer.firstName}</li>
                        <li>Customer Middle Name :{customer.middleName}</li>
                        <li>Customer Last Name :{customer.lastName}</li>
                        <li>Customer Phone Number :{customer.mobileNumber}</li>
                        <li>Customer Addhaar :{customer.addharNumber}</li>
                        <li>Customer Email :{customer.email}</li>
                        <li>Customer Gender :{customer.gender}</li>
                    </ul>
                    </div>:
                    <h5>No Customer Found</h5>

            }
        </div>
        )
    
}