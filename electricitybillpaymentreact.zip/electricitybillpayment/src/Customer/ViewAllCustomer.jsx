
import React,{useEffect,useState} from "react";
import { Link } from "react-router-dom";
import CustomerServices from "../services/CustomerServices";
export default function ViewAllCustomer(){
    const[customers, setCustomers] = useState([])
    const[search,setSearch]= useState('')
    const[filteredNames, setFilteredNames]= useState()
    
    useEffect(()=>{
        CustomerServices.getAllCustomers()
        .then((response)=>
            {
                console.log(response.data)
                console.log(response.status)

                setCustomers(response.data)
            
            })
            .catch(error=>
                {
                    console.log(error)
                    
                })

    },[])

    useEffect(()=>{
        setFilteredNames(
            customers.filter(customer =>{
            return customer.firstName.toLowerCase().includes(search.toLowerCase())

        })

        )
    },[search, customers])
    
        return(
            <div className="container">
            <h2 className="text-center">View All Customer</h2>
            <hr />
            
            <input type="text" placeholder="Search" value={search} onChange={(e)=>setSearch(e.target.value)}/>
            <table className="table table-bordered table-striped">
                <thead>
                    <th> Customer Id</th>
                    <th> First Name</th>
                    <th> Middle Name</th>
                    <th> Last Name</th>
                    <th> Aadhaar Number</th>
                    <th> Mobile Number</th>
                    <th> Email</th>
                    <th> Gender</th> 
                    <th> Action</th>     
                </thead>
                <tbody>
                    {
                        customers.map(
                            customer=>
                            <tr key={customer.customerId}>
                                <td>{customer.customerId}</td>
                                <td>{customer.firstName}</td>
                                <td>{customer.middleName}</td>
                                <td>{customer.lastName}</td>
                                <td>{customer.aadhaarNumber}</td>
                                <td>{customer.mobileNumber}</td>
                                <td>{customer.email}</td>
                                <td>{customer.gender}</td>
                                <td>
                                    <Link className="btn btn-info" to={`/edit-customer/${customer.customerId}`}>EDIT</Link>
                                </td>

                            </tr>
                        )
                    }
                </tbody>
            </table>
        </div>
        )
    
}