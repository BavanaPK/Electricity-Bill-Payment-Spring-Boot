import React, { useEffect, useState } from "react";
import CustomerServices from "../services/CustomerServices";
import { useParams,useHistory } from "react-router";
import { Link } from "react-router-dom";
export default function RegisterCustomer() {

    const [firstName, setFirstName]=useState('')
    const [middleName, setMiddleName]=useState('')
    const [lastName, setLastName]=useState('')
    const [aadhaarNumber, setAadhaarNumber]=useState([])
    const [mobileNumber, setMobileNumber]=useState('')
    const [email, setEmail]=useState('')
    const [gender, setGender]=useState('')
    const history=useHistory();
    const {customerId}=useParams();
    
    const saveOrUpdateCustomer = (e) =>{
        e.preventDefault();
        const customer = {firstName, middleName, lastName, aadhaarNumber, mobileNumber, email, gender }
        if(customerId){
            CustomerServices.editCustomer(customerId, customer)
            .then((response)=>
            {
                console.log(response.data)
                history.push('/view-all-customer');
            }).catch(error=>
            {
                console.log(error)
                
            })
        }
        else{
        CustomerServices.registerCustomer(customer)
        .then((response)=>
        {
            console.log(response.data)
            history.push('/view-all-customer');
            
        
        })
        .catch(error=>
            {
                console.log(error)
                
            })
        }
           
    }


        useEffect(()=>{
            CustomerServices.getCustomerById(customerId).
            then((response)=>{
                setFirstName(response.data.firstName)
                setMiddleName(response.data.middleName)
                setLastName(response.data.lastName)
                setAadhaarNumber(response.data.aadhaarNumber)
                setMobileNumber(response.data.mobileNumber)
                setEmail(response.data.email)
                setGender(response.data.gender)

            })
            .catch(error=>
                {
                    console.log(error)
                    
                })
        },[])
        const title =() =>{
            if(customerId){
                return <h2 className="text=center">Update Customer</h2>
            }
            else{
                return <h2 className="text=center">Register Customer</h2>
            }
        }

        return(
            <div className="container">
            {
                title()
            }
            <div className="card-body">
            <form>
                <div className="form-group mb-2">
                    <label className="form-label">First Name</label>
                    <input type="text" placeholder="Enter First Name"
                        name="firstName" className="form-control"
                        value={firstName}
                        onChange={(e)=>setFirstName(e.target.value)}></input>
                </div>
                <div className="form-group mb-2">
                    <label className="form-label">Middle Name</label>
                    <input type="text" placeholder="Enter Middle Name"
                        name="middleName" className="form-control"
                        value={middleName}
                        onChange={(e)=>setMiddleName(e.target.value)}></input>
                </div>
                <div className="form-group mb-2">
                    <label className="form-label">Last Name</label>
                    <input type="text" placeholder="Enter Last Name"
                        name="lastName" className="form-control"
                        value={lastName}
                        onChange={(e)=>setLastName(e.target.value)}></input>
                </div>
                <div className="form-group mb-2">
                    <label className="form-label">Aadhaar Number</label>
                    <input type="text" placeholder="Enter Aadhaar Number"
                        name="aadhaarNumber" className="form-control"
                        value={aadhaarNumber}
                        onChange={(e)=>setAadhaarNumber(e.target.value)}></input>
                </div>
                <div className="form-group mb-2">
                    <label className="form-label">Mobile Number</label>
                    <input type="text" placeholder="Enter Mobile Number"
                        name="mobileNumber" className="form-control"
                        value={mobileNumber}
                        onChange={(e)=>setMobileNumber(e.target.value)}></input>
                </div>
                <div className="form-group mb-2">
                    <label className="form-label">Email</label>
                    <input type="text" placeholder="Enter Email"
                        name="email" className="form-control"
                        value={email}
                        onChange={(e)=>setEmail(e.target.value)}></input>
                </div>
                <div className="form-group mb-2">
                    <label className="form-label">Gender</label>
                    <input type="text" placeholder="Enter Gender"
                        name="gender" className="form-control"
                        value={gender}
                        onChange={(e)=>setGender(e.target.value)}></input>
                </div>
               
                <button className="btn btn-success mx-2" onClick={(e)=>saveOrUpdateCustomer(e)}>SUBMIT</button>

                <Link to="/view-all-customer" className="btn btn-danger mx-2">CANCEL </Link>
            </form>
            </div>
        </div>
        )
    
}