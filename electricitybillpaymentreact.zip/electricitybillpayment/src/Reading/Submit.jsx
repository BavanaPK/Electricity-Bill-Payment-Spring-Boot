import React from 'react'

function Submit() {
    return (
        <div>
            <h2>fh</h2>
        </div>
    )
}

export default Submit
