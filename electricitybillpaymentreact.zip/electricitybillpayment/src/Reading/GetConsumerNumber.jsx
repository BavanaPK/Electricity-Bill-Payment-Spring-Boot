import React,{useEffect,useState} from "react";
import axios from "axios";
export function GetConsumerNumber() {

    const [consumerNumber,setConsumerNumber]=useState('')
    const [reading,setReading]=useState({})
    const [consumerNumberFromBtn,setConsumerNumberFromBtn]=useState('')
    const [error,setError]=useState(false)

    useEffect(()=>
    {
        axios.get(`http://localhost:8080/reading/consumerNumber/${consumerNumber}`)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)
                setReading(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log("error.msg")
                    setError(true)
                })
    },[consumerNumberFromBtn]
    
    )


    return (
        <div className="container">
            <h2 className="text-primary">Get ConsumerNumber Details</h2>
            <hr/>
            <div className="form-group">
                <label>Consumer Number</label>
                <span className="required" className="text-danger">*</span>
                <input value={consumerNumber} onChange={(event)=>setConsumerNumber(event.target.value)} className="form-control"/>
            </div>
            <button onClick={()=>setConsumerNumberFromBtn(consumerNumber)} className="btn btn-primary mt-3">Serach</button>
            <hr/>
            {
                !error?

                <h5 className="text-danger">Bill Is Not Available</h5>

                :
             <div>
                <h3>Consumer Number:{consumerNumber} Details</h3>
                <ul className="list-group">
                    <li className="list-group-item list-group-item-success">Reading ID: {reading.readingId}</li>
                    <li className="list-group-item list-group-item-primary">Unit Consumed:{reading.unitConsumed}</li>
                    <li className="list-group-item list-group-item-info">Price Per Unit:{reading.priceperunit}</li>
                    <li className="list-group-item list-group-item-danger">Reading Photo:{reading.readingPhoto}</li>
                    <li className="list-group-item list-group-item-warning">Reading Date:{reading.readingDate}</li>
                </ul>
        </div>
        }
        </div>
                    
    ) 
}

