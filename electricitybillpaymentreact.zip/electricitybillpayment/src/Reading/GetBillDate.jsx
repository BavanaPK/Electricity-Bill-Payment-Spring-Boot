import React, {useEffect,useState} from "react";
import axios from "axios";
function GetBillDate() {

    const [billDate,setBillDate] = useState('')
    const [billDateFromBtn,setBillDateFromBtn] = useState('')
    const [reading,setReading]= useState({})
    const [error,setError]=useState(false)

    useEffect(()=>
    {
        axios.get(`http://localhost:8080/reading/billDate/${billDate}`)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)
                setReading(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log("error banthu")
                    setError(true)
                })
    },[billDateFromBtn]
    
    )

   return (
       <div className="container">
           <h3>Search For Bill</h3>
           <hr/>
           <div className="form-group">
            <label>Customer BillDate</label>
            <span className="required" className="text-danger">*</span>
            <input value={billDate} onChange={(event)=>setBillDate(event.target.value)} className="form-control"/>
           </div>
           <button onClick={()=>setBillDateFromBtn(billDate)} className="btn btn-primary mt-3">Search</button>
           <hr/>
           {
               !error?

               <h5 className="text-danger">BillDate Is Not Available</h5>
            : 
            <div>
           <h3>Customer BillDate: {billDate}</h3>
           <ul className="list-group">
           <li className="list-group-item list-group-item-success">Reading ID: {reading.readingId}</li>
                    <li className="list-group-item list-group-item-primary">Unit Consumed:{reading.unitConsumed}</li>
                    <li className="list-group-item list-group-item-info">Price Per Unit:{reading.priceperunit}</li>
                    <li className="list-group-item list-group-item-danger">Reading Photo:{reading.readingPhoto}</li>
                    <li className="list-group-item list-group-item-warning">Reading Date:{reading.readingDate}</li>
                </ul>
           </div>
           
           }
       </div>
   )
}

export default GetBillDate