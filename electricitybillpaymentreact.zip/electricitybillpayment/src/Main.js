import React from 'react'
import { Link } from 'react-router-dom';

export function Main() {
    return (
        <div style={{backgroundColor:'blue'}} >
           <nav class="navbar navbar-expand-lg navbar-dark bg-dark text-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#" style={{fontStyle:"initial"}}>ELectricity Bill Payment</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <Link class="nav-link active" aria-current="page" to="">Home</Link>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           User
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><Link class="dropdown-item" to="user-register">UserRegister</Link></li>
            <li><Link class="dropdown-item" to="login">Login</Link></li>
            
          </ul>
        </li>




        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           Customer
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><Link class="dropdown-item" to="/register-customer">Register Customer</Link></li>
            <li><Link class="dropdown-item" to="/view-all-customer">View All Customer</Link></li>
            <li><Link class="dropdown-item" to="/view-customer-by-id">View Customer By Id</Link></li>
            <li><Link class="dropdown-item" to="/view-customer-by-email">View Customer By Email</Link></li>
            <li><Link class="dropdown-item" to="/view-customer-by-addhar">View Customer By Addhar</Link></li>
            <li><Link class="dropdown-item" to="/view-customer-by-mobile">View Customer By Mobile Number</Link></li>
            <li><Link class="dropdown-item" to="/view-customer-by-name">View Customer By Name</Link></li>
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           Connection
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <li><Link class="dropdown-item" to="/new-connection-request">New Connection Request</Link></li>
            <li><Link class="dropdown-item" to="/view-customer-by-consumer-number">View Customer By Consumer Number</Link></li>
            <li><Link class="dropdown-item" to="/view-active-connections-by-village">View Active Connections By Village</Link></li>
            <li><Link class="dropdown-item" to="/view-active-connections-by-taluk">View Active Connections By Taluk</Link></li>
            <li><Link class="dropdown-item" to="/view-active-connections-by-district">View Active Connections By District</Link></li>
            <li><Link class="dropdown-item" to="/view-active-connections-by-pincode">View Active Connections By Pincode</Link></li>
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           Readings
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            
            <li><Link class="dropdown-item" to="getconsumernumber">GetConsumerNumber</Link></li>
            <li><Link class="dropdown-item" to="getbilldate">GetBillDate</Link></li>
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           Bill
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><Link class="dropdown-item" to="billmobile">BillMobile</Link></li>
            <li><Link class="dropdown-item" to="billconsumernumber">BillConsumerNumber</Link></li>
            <li><Link class="dropdown-item" to="billemail">BillEmail</Link></li>
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           Payment
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><Link class="dropdown-item" to="consumerpay">ConsumerPay</Link></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
        </div>
    )
}


