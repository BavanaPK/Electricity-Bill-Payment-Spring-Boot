import React,{useEffect,useState} from 'react';
import Validation from './Validation';

function Register(){

    
 {/*} const Header=()=>{
    return(
        <header>
            <div className="head-text">
                <div className="head-image">
                    <img src ={img1} alt="Blog"/>
                </div>
                <div class='text-on-image'>
                <h3>Welcome</h3>
                <p>lorem</p>
                </div>
            </div>
        </header>
    )
} 
*/}
    const [values,setValues]=useState({
        username:"",
        email:"",
        password:""
    });

    const [errors,setErrors]=useState({});
    const [dataIsCrt,setDataIsCrt]=useState(false);

    const handleChange=(event)=>{
        setValues({
            ...values,
            [event.target.name]:event.target.value
        });  
    }

    const handleFormSubmit=(event)=>
    {
        event.preventDefault();
        setErrors(Validation(values));
        setDataIsCrt(true);
    };

    return (
        
       
        <div className="container">
        <div className="app-wrapper">
            <div>
            <h2 className="title">Create Account</h2>
        </div> 
        <form className="form-wrapper">
                <div className="username">
                    <label className="label">Username</label>
                    <input className="input" type="text" name="username" value={values.username} 
                    onChange={handleChange}/>
                    {errors.username && <p className="error">{errors.username}</p>}
                </div>

                <div className="email">
                    <label className="label">Email</label>
                    <input className="input" type="email" name="email" value={values.email}
                     onChange={handleChange}/>
                      {errors.email && <p className="error">{errors.email}</p>}
                </div>

                <div className="password">
                    <label className="label">Password</label>
                    <input className="input" type="password"  name="password" value={values.password}
                     onChange={handleChange}/>
                      {errors.password && <p className="error">{errors.password}</p>}
                </div>
                <div>
                    <button className="submit" onClick={handleFormSubmit}>Login</button>
                </div>
        </form>
        </div>
        </div>
        
    )
}

export default Register;

