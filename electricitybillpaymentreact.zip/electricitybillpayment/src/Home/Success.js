import React from 'react';
import "../App.css";

export const Success = () => {
    return (
        <div className="conatiner">
            <div className="app-wrapper">
                <h1 className="form-success">Logged in succesfully </h1>
            </div>
            
        </div>
    )
}
