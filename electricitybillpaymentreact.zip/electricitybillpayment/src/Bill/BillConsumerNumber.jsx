import axios from "axios";
import { useState, useEffect } from "react";
export function BillConsumerNumber() {

    const [consumerNumber,setConsumerNumber] = useState('')
    const [consumerNumberFromBtn,setConsumerNumberFromBtn] = useState('')
    const [bill,setBill]= useState({})
    const [error,setError]=useState(false)

    useEffect(()=>
    {
        axios.get(`http://localhost:8080/bill/consumernumber/${consumerNumber}`)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)
                setBill(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log("error.msg")
                    setError(true)
                })
    },[consumerNumberFromBtn]
    
    )

    return(
        <div className="container">
       <h3 className="#0dcaf0">Search For Bill</h3>
       <hr/>
       <div className="form-group">
        <label>Consumer Number</label>
        <span className="required" className="text-danger">*</span>
        <input value={consumerNumber} onChange={(event)=>setConsumerNumber(event.target.value)} className="form-control" required/>
       </div>
       <button onClick={()=>setConsumerNumberFromBtn(consumerNumber)} className="btn btn-primary mt-3">Search</button>
       <hr/>
       {
           !error?
       <div>
       <h3>Consumer Number : {consumerNumber}</h3>
       <ul className="list-group">
           <li className="list-group-item list-group-item-success">Bill ID : {bill.billId} </li>
           <li className="list-group-item list-group-item-primary">Bill Date : {bill.billDate} </li>
           <li className="list-group-item list-group-item-info">Bill Due Date : {bill.billDueDate}</li>
           <li className="list-group-item list-group-item-danger">Units Consumed : {bill.unitsConsumed}</li>
           <li className="list-group-item list-group-item-warning">Bill Amount : {bill.billAmount}</li>
       </ul>
       </div> : 
       <h5 className="text-danger">Bill Is Not Available</h5>
       }
   </div>
)

}