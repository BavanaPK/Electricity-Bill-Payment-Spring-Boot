import axios from "axios"
import { useState, useEffect } from "react"
export function BillMobile() {

    const [mobileNumber,setMobileNumber] = useState('')
    const [mobileNumberFromBtn,setMobileNumberFromBtn] = useState('')
    const [bill,setBill]= useState({})
    const [error,setError]=useState(false)

    useEffect(()=>
    {
        axios.get(`http://localhost:8080/bill/mobilenumber/${mobileNumber}`)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)
                setBill(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log("error.msg")
                    setError(true)
                })
    },[mobileNumberFromBtn]
    
    )

    return(
            <div className="container">
           <h3>Search For Bill</h3>
           <hr/>
           <div className="form-group">
            <label>Customer Mobile Number</label>
            <span className="required" className="text-danger">*</span>
            <input value={mobileNumber} onChange={(event)=>setMobileNumber(event.target.value)} className="form-control" required/>
           </div>
           <button onClick={()=>setMobileNumberFromBtn(mobileNumber)} className="btn btn-primary mt-3">Search</button>
           <hr/>
           {
               !error?
           <div>
           <h3>Customer Mobile Number : {mobileNumber}</h3>
           <ul className="list-group">
           <li className="list-group-item list-group-item-success">Bill ID : {bill.billId} </li>
           <li className="list-group-item list-group-item-primary">Bill Date : {bill.billDate} </li>
           <li className="list-group-item list-group-item-info">Bill Due Date : {bill.billDueDate}</li>
           <li className="list-group-item list-group-item-danger">Units Consumed : {bill.unitsConsumed}</li>
           <li className="list-group-item list-group-item-warning">Bill Amount : {bill.billAmount}</li>
       </ul>
           </div> : 
           <h5 className="text-danger">Bill Is Not Available</h5>
           }
       </div>
    )
}