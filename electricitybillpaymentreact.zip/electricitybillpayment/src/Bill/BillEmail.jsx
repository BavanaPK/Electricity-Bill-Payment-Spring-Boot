import React, {useEffect,useState} from "react";
import axios from "axios";
export function BillEmail() {

    const [email,setEmail] = useState('')
    const [emailFromBtn,setEmailFromBtn] = useState('')
    const [bill,setBill]= useState({})
    const [error,setError]=useState(false)

    useEffect(()=>
    {
        axios.get(`http://localhost:8080/bill/email/${email}`)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)
                setBill(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log("error.msg")
                    setError(true)
                })
    },[emailFromBtn]
    
    )

   return (
       <div className="container">
           
           <h3>Search For Bill</h3>
           <hr/>
           <div className="form-group">
            <label>Customer Email</label>
            <span className="required" className="text-danger">*</span>
            <input value={email} onChange={(event)=>setEmail(event.target.value)} className="form-control" required/>
           </div>
           <button onClick={()=>setEmailFromBtn(email)} className="btn btn-primary mt-3">Search</button>
           <hr/>
           {
               error?

               <h5 className="text-danger">Bill Is Not Available</h5>
            : 
            <div>
           <h3>Customer Email : {email}</h3>
           <ul className="list-group">
           <li className="list-group-item list-group-item-success">Bill ID : {bill.billId} </li>
           <li className="list-group-item list-group-item-primary">Bill Date : {bill.billDate} </li>
           <li className="list-group-item list-group-item-info">Bill Due Date : {bill.billDueDate}</li>
           <li className="list-group-item list-group-item-danger">Units Consumed : {bill.unitsConsumed}</li>
           <li className="list-group-item list-group-item-warning">Bill Amount : {bill.billAmount}</li>
       </ul>
           </div>
           
           }
       </div>
   )
}